<?php $__env->startPush('custom-css'); ?>
    <link href="<?php echo e(asset('assets/css/register_page.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/login_page.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Entrar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <nav class="navbar fixed-top">
                <ul class="navbar-nav mr-auto mt-2 ml-4">
                    <li>
                        <a href="<?php echo e(route('welcome')); ?>">
                            <span class="text-gray"><i class="fas fa-chevron-left"> Voltar</i></span>
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav mt-2 mr-4">
                    <li class="enter"><span class="text-gray text-account">Ainda não possui conta?</span><a
                            class="text-enter pl-2" href="<?php echo e(route('welcome')); ?>"><b>Cadastrar-se</b></a></li>
                </ul>
            </nav>
        </div>
        <div class="row justify-content-center form">
            <div class="col-md-6">
                <h3 class="text-center"><b class="text-red">Conecte-se para continuar</b></h3>
                <?php if(isset($error)): ?>
                    <div id="msg" class="alert alert-danger text-center">
                        <?php echo e($error); ?>

                    </div>
                <?php elseif(isset($sucess)): ?>
                    <div id="msg" class="alert alert-sucess text-center">
                        <p><?php echo e($sucess); ?></p>
                    </div>
                <?php endif; ?>
                <div class="mt-5 mb-2">
                    <a href="#" title="" class="btn btn-register linkedin">
                        <i class="fab fa-linkedin-in"></i>
                        <span class="ml-2"><?php echo e(__('Continuar com Linkedin')); ?></span>
                    </a>
                </div>
                <div class="or mb-2">
                    <hr> ou
                    <hr>
                </div>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <label for="email"><?php echo e(__('E-Mail*')); ?></label>
                    <div class="form-group row">

                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <label for="password"><?php echo e(__('Senha*')); ?></label>
                    <div class="form-group row">
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="password" required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row mt-4">
                        <div class="col-6">
                            <input id="check-terms" type="checkbox" name="checkbox">
                            <label id="label-check" for="check-terms"> <?php echo e(__('Lembrar-me')); ?></label>
                        </div>
                        <div class="col-6 text-right">
                            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Esqueci a senha')); ?></a>
                        </div>

                    </div>

                    <div class="form-group row mb-0 mt-4">
                        <input type="submit" class="btn btn-register" value="<?php echo e(__('Entrar agora')); ?>">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\hubc\resources\views/auth/login.blade.php ENDPATH**/ ?>