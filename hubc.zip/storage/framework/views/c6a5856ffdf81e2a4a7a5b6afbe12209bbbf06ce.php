<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/welcome_page.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('custom-css'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>" defer></script>
</body>

</html>
<?php /**PATH D:\xampp2\htdocs\hubc\resources\views/layouts/app.blade.php ENDPATH**/ ?>