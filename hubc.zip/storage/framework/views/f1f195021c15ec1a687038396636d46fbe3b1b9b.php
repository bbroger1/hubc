<nav id="sidebar">
    <div class="sidebar-header text-center">
        <img class="img-logo" src="<?php echo e(asset('images/logo_vermelha.png')); ?>" alt="HUBC - Logo">
    </div>

    <ul class="list-unstyled components">
        <span class="sidebar-title"><?php echo e(__('Principal')); ?></span>
        <li class="active">
            <a href="#painelSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                <span class="icon-subtitle"><i class="fas fa-home"></i></span>
                <b class="subtitle"><?php echo e(__('Painel de controle')); ?></b>
            </a>
            <ul class="collapse list-unstyled" id="painelSubmenu">
                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>" alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Dados Gerais')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>" alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Assinaturas')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.vacancies')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Gerir Vagas')); ?>

                        </span>
                    </a>
                </li>
            </ul>
        </li>
        <br />
        <hr>
        <span class="sidebar-title"><?php echo e(__('Utilidades')); ?></span>
        <li>
            <a href="#ferramentasSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                <span class="icon-subtitle"><i class="fas fa-wrench"></i></span>
                <b class="subtitle"><?php echo e(__('Ferramentas')); ?></b>
            </a>
            <ul class="collapse list-unstyled" id="ferramentasSubmenu">
                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Mensagens')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Calendário')); ?>

                        </span>
                    </a>
                </li>
            </ul>
        </li>
        <br />
        <hr>
        <span class="sidebar-title pt-3"><?php echo e(__('Componentes Extras')); ?></span>
        <li>
            <a href="#outrosSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                <span class="icon-subtitle"><i class="fab fa-yandex-international" aria-hidden="true"></i></span>
                <b class="subtitle"><?php echo e(__('Outros')); ?></b>
            </a>
            <ul class="collapse list-unstyled" id="outrosSubmenu">
                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Assinantes')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.candidates')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Candidatos')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.employers')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Empresas')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <span class="sidebar-img">
                            <img class="img-default" src="<?php echo e(asset('images/ellipse_cinza.png')); ?>"
                                alt="Elipse cinza">
                            <img class="img-hover" src="<?php echo e(asset('images/ellipse_vermelha.png')); ?>"
                                alt="Elipse vermelha"> <?php echo e(__('Usuários')); ?>

                        </span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>

    <ul class="list-unstyled CTAs">
        <li>
            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <span><?php echo e(__('Sair')); ?></span>
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH D:\xampp2\htdocs\hubc\resources\views/panel/admin/sidebar.blade.php ENDPATH**/ ?>