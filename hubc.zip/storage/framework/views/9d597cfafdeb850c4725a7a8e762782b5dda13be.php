<?php $__env->startPush('custom-css'); ?>
    <link href="<?php echo e(asset('assets/css/panel/style.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Navigation -->
        <?php echo $__env->make('panel.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="content">
            <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(Request::is('home')): ?>
                <?php echo $__env->make('panel.admin.content.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Request::is('admin/employers')): ?>
                <?php echo $__env->make('panel.admin.content.employers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Request::is('admin/candidates')): ?>
                <?php echo $__env->make('panel.admin.content.candidates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Request::is('admin/vacancies')): ?>
                <?php echo $__env->make('panel.admin.content.vacancies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Request::is('admin/vacancies/analysis/*')): ?>
                <?php echo $__env->make('panel.admin.content.vacanciesAnalysis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\hubc\resources\views/panel/admin/home.blade.php ENDPATH**/ ?>